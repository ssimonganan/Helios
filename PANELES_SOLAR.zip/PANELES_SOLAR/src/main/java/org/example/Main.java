import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Bienvenido HELIOS Paneles Solares");

        while (true) {
            // MENU PRINCIPAL
            System.out.println("Menú de opciones:");
            System.out.println("1. Ver productos");
            System.out.println("2. Registrar usuario");
            System.out.println("3. Solicitar cotización");
            System.out.println("4. Soporte técnico");
            System.out.println("5. Salir");
            System.out.print("Elige una opción: ");
            int opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    verProductos();
                    break;
                case 2:
                    registrarUsuario(scanner);
                    break;
                case 3:
                    solicitarCotizacion(scanner);
                    break;
                case 4:
                    soporteTecnico(scanner);
                    break;
                case 5:
                    System.out.println("¡Gracias por visitar nuestra página!");
                    return;
                default:
                    System.out.println("Opción no válida.");
            }
        }
    }

    // MOSTRA OPCIONES DE PRODUCTOS
    private static void verProductos() {
        System.out.println("Nuestros productos:");
        System.out.println("1. Panel solar básico (100W)");
        System.out.println("2. Panel solar intermedio (250W)");
        System.out.println("3. Panel solar avanzado (500W)");
    }

    // REGISTRAR UN NUEVO USUARIO
    private static void registrarUsuario(Scanner scanner) {
        System.out.println("Registro de usuario:");

        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();

        System.out.print("Correo: ");
        String correo = scanner.nextLine();

        System.out.print("Teléfono: ");
        String telefono = scanner.nextLine();

        System.out.println("¡Registro exitoso!");
        System.out.println("Nombre: " + nombre);
        System.out.println("Correo: " + correo);
        System.out.println("Teléfono: " + telefono);
    }

    // SOLICITAR UNA COTIZACION
    private static void solicitarCotizacion(Scanner scanner) {
        System.out.println("Solicitar cotización:");

        System.out.print("Ciudad: ");
        String ciudad = scanner.nextLine();

        System.out.print("Tipo de panel (100W, 250W, 500W): ");
        String tipoPanel = scanner.nextLine();

        System.out.println("Cotización solicitada para " + tipoPanel + " en " + ciudad + ".");
    }

    // OPCIONES DE SOPORTE TECNICO
    private static void soporteTecnico(Scanner scanner) {
        System.out.println("Opciones de soporte técnico:");
        System.out.println("1. Instalación");
        System.out.println("2. Mantenimiento");
        System.out.println("3. Reparaciones");
        System.out.print("Elige una opción: ");
        int opcion = scanner.nextInt();
        scanner.nextLine();

        switch (opcion) {
            case 1:
                System.out.println("Instalación programada.");
                break;
            case 2:
                System.out.println("Mantenimiento programado.");
                break;
            case 3:
                System.out.println("Reparación programada.");
                break;
            default:
                System.out.println("Opción no válida.");
        }
    }
}